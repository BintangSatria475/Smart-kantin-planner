SMART KANTIN PLANNER

Struktur:
- app.py                 : Backend Python (Flask)
- templates/index.html   : Tampilan HTML
- static/style.css       : Desain desktop dan mobile
- requirements.txt       : Dependensi

Cara menjalankan:
1. Pastikan Python sudah terpasang.
2. Buka terminal di folder proyek.
3. Jalankan: python -m venv venv
4. Aktifkan virtual environment:
   Windows: venv\Scripts\activate
   macOS/Linux: source venv/bin/activate
5. Instal Flask: pip install -r requirements.txt
6. Jalankan aplikasi: python app.py
7. Buka browser: http://127.0.0.1:5000

Catatan:
- Data menu masih berupa data contoh di memori aplikasi.
- Perubahan data akan kembali ke contoh awal ketika server dimatikan.
- Untuk penggunaan sungguhan, tambahkan database seperti SQLite.
