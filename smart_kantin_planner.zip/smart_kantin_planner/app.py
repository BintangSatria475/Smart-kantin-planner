from flask import Flask, render_template, request, redirect, url_for, flash
from datetime import date

app = Flask(__name__)
app.secret_key = "smart-kantin-planner-demo"

# Data contoh. Untuk penggunaan nyata, data sebaiknya disimpan di database.
menu_items = [
    {"id": 1, "name": "Nasi Ayam Teriyaki", "category": "Makanan", "price": 15000, "stock": 24, "sold": 18},
    {"id": 2, "name": "Mie Goreng", "category": "Makanan", "price": 12000, "stock": 16, "sold": 12},
    {"id": 3, "name": "Es Teh", "category": "Minuman", "price": 5000, "stock": 40, "sold": 31},
    {"id": 4, "name": "Jus Jeruk", "category": "Minuman", "price": 8000, "stock": 10, "sold": 7},
]
next_id = 5

@app.route("/")
def index():
    total_menu = len(menu_items)
    total_stock = sum(item["stock"] for item in menu_items)
    total_sold = sum(item["sold"] for item in menu_items)
    revenue = sum(item["price"] * item["sold"] for item in menu_items)
    low_stock = [item for item in menu_items if item["stock"] <= 10]
    return render_template(
        "index.html",
        menu_items=menu_items,
        total_menu=total_menu,
        total_stock=total_stock,
        total_sold=total_sold,
        revenue=revenue,
        low_stock=low_stock,
        today=date.today().strftime("%d %B %Y"),
    )

@app.route("/add", methods=["POST"])
def add_menu():
    global next_id
    name = request.form.get("name", "").strip()
    category = request.form.get("category", "Makanan")
    try:
        price = int(request.form.get("price", 0))
        stock = int(request.form.get("stock", 0))
    except ValueError:
        flash("Harga dan stok harus berupa angka.", "error")
        return redirect(url_for("index"))

    if not name or price < 0 or stock < 0:
        flash("Lengkapi nama menu dan masukkan angka yang valid.", "error")
        return redirect(url_for("index"))

    menu_items.append({
        "id": next_id, "name": name, "category": category,
        "price": price, "stock": stock, "sold": 0
    })
    next_id += 1
    flash(f"Menu {name} berhasil ditambahkan.", "success")
    return redirect(url_for("index"))

@app.route("/update-stock/<int:item_id>", methods=["POST"])
def update_stock(item_id):
    try:
        amount = int(request.form.get("stock", 0))
    except ValueError:
        amount = -1
    for item in menu_items:
        if item["id"] == item_id:
            if amount >= 0:
                item["stock"] = amount
                flash("Stok berhasil diperbarui.", "success")
            else:
                flash("Stok harus berupa angka nol atau lebih.", "error")
            break
    return redirect(url_for("index"))

@app.route("/delete/<int:item_id>", methods=["POST"])
def delete_menu(item_id):
    global menu_items
    menu_items = [item for item in menu_items if item["id"] != item_id]
    flash("Menu berhasil dihapus.", "success")
    return redirect(url_for("index"))

if __name__ == "__main__":
    app.run(debug=True)
